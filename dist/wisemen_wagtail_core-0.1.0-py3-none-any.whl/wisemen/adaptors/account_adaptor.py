from allauth.account.adapter import DefaultAccountAdapter
from django_rq import get_queue
from environ import Env

from wisemen.email import send_templated_mail


class AccountAdapter(DefaultAccountAdapter):
    """
    Custom AccountAdapter to send emails asynchronously.

    For now only used for email confirmation.
    @Todo: Add other emails to this adapter.
    """
    def send_mail(self, template_prefix, email, context):
        msg = self.render_mail(template_prefix, email, context)

        ENV = Env()  # noqa: N806
        queue = get_queue(ENV("REDIS_QUEUE"))

        template_variables = {}
        if template_prefix == "account/email/email_confirmation_signup":
            template_variables = {
                "email": email,
                "key": context["key"]
            }

        queue.enqueue(
            send_templated_mail,
            to_addresses=msg.to,
            subject=msg.subject,
            template_name=f"{template_prefix}.html",
            template_variables=template_variables,
            tags=template_prefix.split("/")[1:],
        )