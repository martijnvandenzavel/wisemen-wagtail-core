from rest_framework import serializers


class ImageSerializer(serializers.Serializer):
    def __init__(self, *args, rendition="original", **kwargs):
        super(ImageSerializer, self).__init__(*args, **kwargs)
        self.rendition = rendition

    def to_representation(self, instance):
        return {
            "title": instance.title,
            "url": instance.get_rendition(self.rendition).file.url,
            "meta": instance.get_rendition(self.rendition).meta,
        }