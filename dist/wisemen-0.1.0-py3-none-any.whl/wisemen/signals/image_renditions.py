from django_rq import get_queue
from django.db.models.signals import post_save
from django.dispatch import receiver
from wagtail.images.models import Image
from environ import Env

from wisemen.helpers.image_renditions import generate_renditions


@receiver(post_save, sender=Image)
def image_saved(sender, instance, **kwargs):
    ENV = Env()

    queue = get_queue(ENV("REDIS_QUEUE"))
    queue.enqueue(generate_renditions, instance)