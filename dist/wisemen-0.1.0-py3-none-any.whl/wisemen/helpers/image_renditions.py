from wagtail.images.models import Image


def generate_renditions(image: Image):
    """
    Generate the various default renditions required when viewing
    the admin image overview and image edit pages.

    :param image:
    :return:
    """
    # Generate the rendition for editing the image in the admin ("max-800x600" and "original").
    image.get_rendition("max-800x600")
    image.get_rendition("original")

    # Generate the rendition for admin overview page ("max-165x165").
    image.get_rendition("max-165x165")
