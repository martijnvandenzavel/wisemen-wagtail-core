from django import forms
from wagtail.admin.panels import (
    FieldPanel,
    MultiFieldPanel,
)
from django.utils.translation import gettext_lazy as _


def seo_panels(disable_slug=False):
    widget = forms.TextInput()

    if disable_slug:
        return [
            MultiFieldPanel(
                [
                    FieldPanel("seo_title"),
                    FieldPanel("search_description"),
                    FieldPanel("og_image"),
                ],
                _("Search and Social Previews"),
            )
        ]
    else:
        return [
            MultiFieldPanel(
                [
                    FieldPanel("slug", widget=widget),
                    FieldPanel("seo_title"),
                    FieldPanel("search_description"),
                    FieldPanel("og_image"),
                ],
                _("Search and Social Previews"),
            )
        ]
